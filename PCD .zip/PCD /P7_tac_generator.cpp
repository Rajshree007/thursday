#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <cctype>
#include <cstring>
#include <stdexcept>
#include <sstream>
using namespace std;

static int tempCount = 0;
static int labelCount = 0;
static vector<string> code;               
string intToStr(int n) { ostringstream os; os << n; return os.str(); }
string newTemp()  { return "t" + intToStr(++tempCount); }
string newLabel() { return "L" + intToStr(++labelCount); }
void emit(const string &s) { code.push_back(s); }


vector<string> tokenize(const string &s) {
    vector<string> tokens;
    size_t i = 0;
    while (i < s.size()) {
        char c = s[i];
        if (isspace((unsigned char)c)) { i++; continue; }
        if (isalnum((unsigned char)c) || c == '_' || c == '.') {   // identifier / number
            size_t j = i;
            while (j < s.size() && (isalnum((unsigned char)s[j]) || s[j] == '_' || s[j] == '.')) j++;
            tokens.push_back(s.substr(i, j - i));
            i = j;
        } else {
            string two = s.substr(i, 2);
            if (two == "<=" || two == ">=" || two == "==" || two == "!=" ||
                two == "&&" || two == "||") {
                tokens.push_back(two);
                i += 2;
            } else if (strchr("+-*/%<>()", c)) {
                tokens.push_back(string(1, c));
                i++;
            } else {
                throw runtime_error(string("Invalid character '") + c + "' in expression");
            }
        }
    }
    return tokens;
}


int prec(const string &op) {
    if (op == "||") return 1;
    if (op == "&&") return 2;
    if (op == "==" || op == "!=") return 3;
    if (op == "<" || op == ">" || op == "<=" || op == ">=") return 4;
    if (op == "+" || op == "-") return 5;
    if (op == "*" || op == "/" || op == "%") return 6;
    return 0;
}

vector<string> toPostfix(const vector<string> &tokens) {
    vector<string> out;
    stack<string> ops;
    for (size_t k = 0; k < tokens.size(); k++) {
        const string &t = tokens[k];
        if (t == "(") {
            ops.push(t);
        } else if (t == ")") {
            while (!ops.empty() && ops.top() != "(") { out.push_back(ops.top()); ops.pop(); }
            if (ops.empty()) throw runtime_error("Mismatched parentheses");
            ops.pop();                                   
        } else if (prec(t) > 0) {
            while (!ops.empty() && ops.top() != "(" && prec(ops.top()) >= prec(t)) {
                out.push_back(ops.top());
                ops.pop();
            }
            ops.push(t);
        } else {
            out.push_back(t);                       
        }
    }
    while (!ops.empty()) {
        if (ops.top() == "(") throw runtime_error("Mismatched parentheses");
        out.push_back(ops.top());
        ops.pop();
    }
    return out;
}

string genExprTAC(const string &expr) {
    vector<string> postfix = toPostfix(tokenize(expr));
    stack<string> st;
    for (size_t k = 0; k < postfix.size(); k++) {
        const string &t = postfix[k];
        if (prec(t) > 0) {
            if (st.size() < 2) throw runtime_error("Malformed expression: '" + expr + "'");
            string b = st.top(); st.pop();
            string a = st.top(); st.pop();
            string tmp = newTemp();
            emit(tmp + " = " + a + " " + t + " " + b);
            st.push(tmp);
        } else {
            st.push(t);
        }
    }
    if (st.size() != 1) throw runtime_error("Malformed expression: '" + expr + "'");
    return st.top();
}

void genAssignTAC(const string &stmt) {
    size_t eq = string::npos;
    for (size_t i = 0; i < stmt.size(); i++) {
        if (stmt[i] != '=') continue;
        bool nextEq = (i + 1 < stmt.size() && stmt[i + 1] == '=');
        bool prevOp = (i > 0 && strchr("<>!=", stmt[i - 1]));
        if (!nextEq && !prevOp) { eq = i; break; }
    }
    if (eq == string::npos) throw runtime_error("Not an assignment: '" + stmt + "'");

    string lhs = stmt.substr(0, eq);
    string rhs = stmt.substr(eq + 1);

    size_t b = lhs.find_first_not_of(" \t"), e = lhs.find_last_not_of(" \t");
    if (b == string::npos) throw runtime_error("Missing left-hand side in: '" + stmt + "'");
    lhs = lhs.substr(b, e - b + 1);

    string result = genExprTAC(rhs);
    emit(lhs + " = " + result);
}

void readBlock(const string &title, vector<string> &stmts) {
    int n;
    cout << "Number of statements in " << title << ": ";
    cin >> n;
    cin.ignore(1000, '\n');
    for (int i = 1; i <= n; i++) {
        string s;
        cout << "  " << title << " statement " << i << " (e.g. x = a + b * c): ";
        getline(cin, s);
        stmts.push_back(s);
    }
}


void genIfElse(const string &cond, const vector<string> &thenS, const vector<string> &elseS) {
    string L1 = newLabel(), L2 = newLabel();
    string c = genExprTAC(cond);
    emit("ifFalse " + c + " goto " + L1);
    for (size_t k = 0; k < thenS.size(); k++) genAssignTAC(thenS[k]);
    emit("goto " + L2);
    emit(L1 + ":");
    for (size_t k = 0; k < elseS.size(); k++) genAssignTAC(elseS[k]);
    emit(L2 + ":");
}

void genWhile(const string &cond, const vector<string> &body) {
    string L1 = newLabel(), L2 = newLabel();
    emit(L1 + ":");
    string c = genExprTAC(cond);
    emit("ifFalse " + c + " goto " + L2);
    for (size_t k = 0; k < body.size(); k++) genAssignTAC(body[k]);
    emit("goto " + L1);
    emit(L2 + ":");
}

int main() {
    cout << "=== Three-Address Code Generator (Control Statements) ===\n"
         << "1. if (B) S1 else S2\n"
         << "2. while (B) S1\n"
         << "Enter choice: ";
    int choice;
    if (!(cin >> choice)) return 1;
    cin.ignore(1000, '\n');

    string cond;
    cout << "Enter Boolean condition B (e.g. a < b): ";
    getline(cin, cond);

    try {
        if (choice == 1) {
            vector<string> thenS, elseS;
            readBlock("THEN", thenS);
            readBlock("ELSE", elseS);
            genIfElse(cond, thenS, elseS);
        } else if (choice == 2) {
            vector<string> body;
            readBlock("BODY", body);
            genWhile(cond, body);
        } else {
            cerr << "Invalid choice.\n";
            return 1;
        }
    } catch (const exception &ex) {
        cerr << "Error: " << ex.what() << "\n";
        return 1;
    }

    cout << "\n--- Generated Three-Address Code ---\n";
    for (size_t k = 0; k < code.size(); k++) {
        const string &line = code[k];
        if (!line.empty() && line[line.size() - 1] == ':') cout << line << "\n";   
        else                                      cout << "    " << line << "\n";
    }
    return 0;
}