#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
using namespace std;

bool parseNumber(const string &s, double &val) {
    if (s.empty()) return false;
    size_t i = (s[0] == '-' || s[0] == '+') ? 1 : 0;
    if (i >= s.size()) return false;
    int dots = 0, digits = 0;
    for (; i < s.size(); i++) {
        if (isdigit((unsigned char)s[i])) digits++;
        else if (s[i] == '.') dots++;
        else return false;
    }
    if (digits == 0 || dots > 1) return false;
    val = stod(s);
    return true;
}

string fmt(double v) {
    char buf[64];
    snprintf(buf, sizeof buf, "%.10g", v);
    return string(buf);
}

string foldStatement(const string &line) {
    istringstream ss(line);
    vector<string> t;
    string w;
    while (ss >> w) t.push_back(w);

    if (t.size() != 5 || t[1] != "=") return line;

    double a, b;
    if (!parseNumber(t[2], a) || !parseNumber(t[4], b)) return line;  

    const string &op = t[3];
    double r;
    if      (op == "+") r = a + b;
    else if (op == "-") r = a - b;
    else if (op == "*") r = a * b;
    else if (op == "/") {
        if (b == 0) return line;          
        r = a / b;
    } else return line;  

    return t[0] + " = " + fmt(r);
}

int main() {
    cout << "Enter TAC statements, blank line to finish:\n";
    vector<string> before;
    string line;
    while (getline(cin, line)) {
        if (line.find_first_not_of(" \t\r\n") == string::npos) break;
        before.push_back(line);
    }

    cout << "\nBefore optimization:\n";
    for (auto &s : before) cout << "    " << s << "\n";

    cout << "\nAfter constant folding:\n";
    for (auto &s : before) cout << "    " << foldStatement(s) << "\n";
    return 0;
}

