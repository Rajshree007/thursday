#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <sstream>
using namespace std;

string intToStr(int n) { ostringstream os; os << n; return os.str(); }
string regName(int c)  { return "R" + intToStr(c); }

int fail(const string &msg) {
    cerr << "Error: " << msg << "\n";
    return 1;
}

int main() {
    cout << "=== Graph-Coloring Register Allocation ===\n"
         << "Input: n, then n variable names, then m, then m edges (u v), then K.\n\n";

   
    int n;
    if (!(cin >> n) || n < 1 || n > 200) return fail("number of variables must be between 1 and 200");

    vector<string> name(n);
    map<string, int> idx;
    for (int i = 0; i < n; i++) {
        if (!(cin >> name[i])) return fail("incomplete input while reading variable names");
        if (idx.count(name[i])) return fail("duplicate variable name '" + name[i] + "'");
        idx[name[i]] = i;
    }

    int m;
    if (!(cin >> m) || m < 0) return fail("invalid number of edges");
    vector<vector<bool> > adj(n, vector<bool>(n, false));
    int edgeCount = 0;
    for (int e = 0; e < m; e++) {
        string u, v;
        if (!(cin >> u >> v)) return fail("incomplete input while reading edges");
        if (!idx.count(u)) return fail("unknown variable '" + u + "' in edge list");
        if (!idx.count(v)) return fail("unknown variable '" + v + "' in edge list");
        int a = idx[u], b = idx[v];
        if (a == b) { cout << "Warning: self-edge " << u << "-" << v << " ignored\n"; continue; }
        if (!adj[a][b]) { adj[a][b] = adj[b][a] = true; edgeCount++; }
    }

    int K;
    if (!(cin >> K) || K < 1) return fail("K must be a positive integer");

 
    vector<int> degree(n, 0);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            if (adj[i][j]) degree[i]++;

    cout << "\nVariables: " << n << "   Interference edges: " << edgeCount
         << "   Registers K = " << K << "\n\n--- Interference graph ---\n";
    for (int i = 0; i < n; i++) {
        cout << setw(8) << left << name[i] << right << " degree " << degree[i] << " : ";
        bool any = false;
        for (int j = 0; j < n; j++)
            if (adj[i][j]) { cout << (any ? ", " : "") << name[j]; any = true; }
        if (!any) cout << "(no neighbours)";
        cout << "\n";
    }

  
    cout << "\n--- Simplify phase ---\n";
    vector<bool> removed(n, false), potential(n, false);
    vector<int> stk;
    for (int step = 1; step <= n; step++) {
        vector<int> cur(n, 0);                      
        for (int i = 0; i < n; i++) {
            if (removed[i]) continue;
            for (int j = 0; j < n; j++)
                if (adj[i][j] && !removed[j]) cur[i]++;
        }

        int pick = -1;
        for (int i = 0; i < n; i++)
            if (!removed[i] && cur[i] < K) { pick = i; break; }

        cout << "Step " << setw(2) << step << ": ";
        if (pick >= 0) {
            cout << "push " << name[pick] << "  (degree " << cur[pick] << " < K=" << K << ")\n";
        } else {
            int best = -1;
            for (int i = 0; i < n; i++)
                if (!removed[i] && cur[i] > best) { best = cur[i]; pick = i; }
            potential[pick] = true;
            cout << "no vertex has degree < " << K << "; push " << name[pick]
                 << "  (highest degree " << best << ") as POTENTIAL SPILL\n";
        }
        stk.push_back(pick);
        removed[pick] = true;
    }


    cout << "\n--- Select phase ---\n";
    vector<int> color(n, -1);
    vector<bool> spilled(n, false);
    for (int step = 1; !stk.empty(); step++) {
        int v = stk.back();
        stk.pop_back();

        vector<bool> used(K, false);
        string nb;
        for (int j = 0; j < n; j++) {
            if (adj[v][j] && color[j] >= 0) {
                used[color[j]] = true;
                nb += (nb.empty() ? "" : ", ") + name[j] + "=" + regName(color[j]);
            }
        }
        int c = -1;
        for (int k = 0; k < K; k++)
            if (!used[k]) { c = k; break; }

        cout << "Pop  " << setw(2) << step << ": " << name[v] << "  colored neighbours {"
             << (nb.empty() ? "none" : nb) << "}  -> ";
        if (c >= 0) {
            color[v] = c;
            cout << "assign " << regName(c);
            if (potential[v]) cout << "  (potential spill, colored successfully)";
            cout << "\n";
        } else {
            spilled[v] = true;
            cout << "all " << K << " colors blocked -> SPILL\n";
        }
    }

    cout << "\n--- Register allocation result ---\n";
    cout << left << setw(10) << "Variable" << setw(10) << "Degree" << "Location\n" << right;
    int spillCount = 0;
    vector<bool> colorUsed(K, false);
    for (int i = 0; i < n; i++) {
        cout << left << setw(10) << name[i] << setw(10) << degree[i];
        if (spilled[i]) { cout << "SPILL (memory)\n"; spillCount++; }
        else            { cout << regName(color[i]) << "\n"; colorUsed[color[i]] = true; }
        cout << right;
    }
    int regsUsed = 0;
    for (int k = 0; k < K; k++) if (colorUsed[k]) regsUsed++;
    cout << "\nRegisters used : " << regsUsed << " of " << K << "\n"
         << "Spilled        : " << spillCount;
    if (spillCount > 0) {
        cout << "  (";
        bool first = true;
        for (int i = 0; i < n; i++)
            if (spilled[i]) { cout << (first ? "" : ", ") << name[i]; first = false; }
        cout << ")";
    }
    cout << "\n";


    bool ok = true;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (adj[i][j] && !spilled[i] && !spilled[j] && color[i] == color[j]) ok = false;
    cout << "Verification   : " << (ok ? "valid (no interfering pair shares a register)" : "INVALID") << "\n";
    return ok ? 0 : 1;
}