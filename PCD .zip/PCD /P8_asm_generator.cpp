#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <sstream>
#include <cctype>
#include <stdexcept>
using namespace std;

const int  NREG = 4;
const bool STORE_TEMPS_AT_END = false;

struct Reg {
    string var;      
    bool   dirty;
};

Reg regs[NREG];
map<string, int> where;     
int rrNext = 0;        

string intToStr(int n) { ostringstream os; os << n; return os.str(); }
string regName(int r)  { return "R" + intToStr(r); }
void emit(const string &s) { cout << "    " << s << "\n"; }

bool isConst(const string &s) {
    size_t i = 0;
    if (s.empty()) return false;
    if (s[0] == '-') i = 1;
    bool digit = false;
    for (; i < s.size(); i++) {
        if (isdigit((unsigned char)s[i])) digit = true;
        else if (s[i] != '.') return false;
    }
    return digit;
}
bool isIdent(const string &s) {
    if (s.empty() || !(isalpha((unsigned char)s[0]) || s[0] == '_')) return false;
    for (size_t i = 1; i < s.size(); i++)
        if (!(isalnum((unsigned char)s[i]) || s[i] == '_')) return false;
    return true;
}
bool isTemp(const string &s) {        
    if (s.size() < 2 || s[0] != 't') return false;
    for (size_t i = 1; i < s.size(); i++)
        if (!isdigit((unsigned char)s[i])) return false;
    return true;
}
bool isScratch(const string &v) { return !v.empty() && v[0] == '#'; }


int inReg(const string &v) {
    map<string, int>::iterator it = where.find(v);
    return (it == where.end()) ? -1 : it->second;
}
void freeReg(int r) {                      
    if (!regs[r].var.empty() && !isScratch(regs[r].var)) where.erase(regs[r].var);
    regs[r].var = "";
    regs[r].dirty = false;
}
void setReg(int r, const string &v, bool dirty) {
    regs[r].var = v;
    regs[r].dirty = dirty;
    where[v] = r;
}


int getreg(const set<int> &avoid) {
 
    for (int r = 0; r < NREG; r++)
        if (regs[r].var.empty() && avoid.count(r) == 0) return r;

    int victim = -1;
    for (int i = 0; i < NREG; i++) {
        int c = (rrNext + i) % NREG;
        if (avoid.count(c) == 0) { victim = c; break; }
    }
    if (victim < 0) throw runtime_error("getreg(): no register available");
    rrNext = (victim + 1) % NREG;


    if (regs[victim].dirty)
        emit("STORE " + regs[victim].var + ", " + regName(victim));
    freeReg(victim);
    return victim;
}


int ensureInReg(const string &v, const set<int> &avoid) {
    if (isConst(v)) {
        int r = getreg(avoid);
        emit("MOV " + regName(r) + ", #" + v);
        regs[r].var = "#" + v;           
        regs[r].dirty = false;
        return r;
    }
    int r = inReg(v);
    if (r >= 0) return r;
    r = getreg(avoid);
    emit("LOAD " + regName(r) + ", " + v);
    setReg(r, v, false);
    return r;
}


void genCopy(const string &x, const string &y) {
    if (isConst(y)) {                             
        int rx = inReg(x);
        int rd = (rx >= 0) ? rx : getreg(set<int>());
        emit("MOV " + regName(rd) + ", #" + y);
        setReg(rd, x, true);
        return;
    }
    int ry = ensureInReg(y, set<int>());             
    int rx = inReg(x);                                  
    if (rx == ry) { emit("; " + x + " = " + y + " needs no code"); return; }
    int rd;
    if (rx >= 0) rd = rx;
    else { set<int> av; av.insert(ry); rd = getreg(av); }
    emit("MOV " + regName(rd) + ", " + regName(ry));
    setReg(rd, x, true);
}

void genBinary(const string &x, const string &y, const string &op, const string &z) {
    string mn = (op == "+") ? "ADD" : (op == "-") ? "SUB" : (op == "*") ? "MUL" : "DIV";

    int ry = isConst(y) ? -1 : inReg(y);                
    set<int> avoidY;
    if (ry >= 0) avoidY.insert(ry);
    int rz = ensureInReg(z, avoidY);                   

    int rx = inReg(x);                             
    int rd;
    if (rx >= 0 && rx != rz) {
        rd = rx;                                 
    } else {
        set<int> av;
        av.insert(rz);
        if (ry >= 0) av.insert(ry);
        rd = getreg(av);
    }


    if (ry == rd) { /* already there */ }
    else if (ry >= 0)  emit("MOV " + regName(rd) + ", " + regName(ry));
    else if (isConst(y)) emit("MOV " + regName(rd) + ", #" + y);
    else                 emit("LOAD " + regName(rd) + ", " + y);

    emit(mn + " " + regName(rd) + ", " + regName(rz));

    // update descriptors
    if (isScratch(regs[rz].var)) freeReg(rz);          
    if (rx >= 0 && rx != rd) freeReg(rx);               
    setReg(rd, x, true);                                
}

void printState() {
    cout << "    ; ";
    for (int r = 0; r < NREG; r++) {
        cout << regName(r) << "=";
        if (regs[r].var.empty()) cout << "-";
        else cout << regs[r].var << (regs[r].dirty ? "*" : "");
        cout << (r + 1 < NREG ? "  " : "");
    }
    cout << "     (* = dirty)\n";
}


struct Stmt {
    string text, x, y, op, z;    
};

Stmt parseLine(const string &line, int lineNo) {
    vector<string> t;
    istringstream in(line);
    string w;
    while (in >> w) t.push_back(w);

    Stmt s;
    s.text = line;
    string where_ = "line " + intToStr(lineNo) + ": ";
    if ((t.size() != 3 && t.size() != 5) || t[1] != "=")
        throw runtime_error(where_ + "expected 'x = y' or 'x = y op z' with spaces: '" + line + "'");
    if (!isIdent(t[0]))
        throw runtime_error(where_ + "invalid destination '" + t[0] + "'");
    s.x = t[0];
    if (!isIdent(t[2]) && !isConst(t[2]))
        throw runtime_error(where_ + "invalid operand '" + t[2] + "'");
    s.y = t[2];
    if (t.size() == 5) {
        if (t[3] != "+" && t[3] != "-" && t[3] != "*" && t[3] != "/")
            throw runtime_error(where_ + "unsupported operator '" + t[3] + "' (use + - * /)");
        if (!isIdent(t[4]) && !isConst(t[4]))
            throw runtime_error(where_ + "invalid operand '" + t[4] + "'");
        s.op = t[3];
        s.z = t[4];
    }
    return s;
}

int main() {
    cout << "=== Assembly Code Generator with getreg() (registers R0-R" << NREG - 1 << ") ===\n"
         << "Enter TAC statements, one per line (x = y  or  x = y op z).\n"
         << "Finish with an empty line.\n";

    vector<Stmt> prog;
    string line;
    try {
        int n = 0;
        while (getline(cin, line)) {
            n++;
            if (line.find_first_not_of(" \t\r") == string::npos) break;
            prog.push_back(parseLine(line, n));
        }
    } catch (const exception &ex) {
        cerr << "Error: " << ex.what() << "\n";
        return 1;
    }

    for (int r = 0; r < NREG; r++) { regs[r].var = ""; regs[r].dirty = false; }

    cout << "\n--- Generated Assembly ---\n";
    try {
        for (size_t i = 0; i < prog.size(); i++) {
            const Stmt &s = prog[i];
            cout << "; " << s.x << " = " << s.y;
            if (!s.op.empty()) cout << " " << s.op << " " << s.z;
            cout << "\n";
            if (s.op.empty()) genCopy(s.x, s.y);
            else              genBinary(s.x, s.y, s.op, s.z);
            printState();
        }


        cout << "; end of block - store dirty values\n";
        for (int r = 0; r < NREG; r++) {
            if (regs[r].var.empty() || isScratch(regs[r].var) || !regs[r].dirty) continue;
            if (isTemp(regs[r].var) && !STORE_TEMPS_AT_END) continue;
            emit("STORE " + regs[r].var + ", " + regName(r));
            regs[r].dirty = false;
        }
    } catch (const exception &ex) {
        cerr << "Error: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}